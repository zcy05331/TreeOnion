# Profile Summary

- Source samples: 6830
- Summary rows: 98

| scale | case | variant | stage | unit | basis | count | mean | median | p95 | stdev | peak RSS bytes |
| --- | --- | --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 8gb | merkle_layerwise | merkle_layerwise | helper_key_bytes | bytes | modeled | 1 | 1488000.000 | 1488000.000 | 1488000.000 | 0.000 | 47580418048 |
| 8gb | merkle_layerwise | merkle_layerwise | online_total_bytes | bytes | mixed | 1 | 553056.000 | 553056.000 | 553056.000 | 0.000 | 47580418048 |
| 8gb | merkle_layerwise | merkle_layerwise | query_upload_bytes | bytes | modeled | 1 | 312480.000 | 312480.000 | 312480.000 | 0.000 | 47580418048 |
| 8gb | merkle_layerwise | merkle_layerwise | response_download_bytes | bytes | actual | 1 | 240576.000 | 240576.000 | 240576.000 | 0.000 | 47580418048 |
| 8gb | merkle_layerwise | merkle_layerwise | server_compute_ms | ms | actual | 100 | 20702.123 | 20720.040 | 20760.285 | 46.730 | 47580418048 |
| 8gb | merkle_layerwise_profiled | merkle_layerwise_profiled | helper_key_bytes | bytes | modeled | 1 | 1488000.000 | 1488000.000 | 1488000.000 | 0.000 | 46384926720 |
| 8gb | merkle_layerwise_profiled | merkle_layerwise_profiled | online_total_bytes | bytes | mixed | 1 | 553056.000 | 553056.000 | 553056.000 | 0.000 | 46384926720 |
| 8gb | merkle_layerwise_profiled | merkle_layerwise_profiled | query_upload_bytes | bytes | modeled | 1 | 312480.000 | 312480.000 | 312480.000 | 0.000 | 46384926720 |
| 8gb | merkle_layerwise_profiled | merkle_layerwise_profiled | response_download_bytes | bytes | actual | 1 | 240576.000 | 240576.000 | 240576.000 | 0.000 | 46384926720 |
| 8gb | merkle_layerwise_profiled | merkle_layerwise_profiled | server_compute_ms | ms | actual | 100 | 12331.324 | 12334.631 | 12378.551 | 41.434 | 46384926720 |
| 8gb | standard_onionpir | standard_onionpir | helper_key_bytes | bytes | modeled | 1 | 1488000.000 | 1488000.000 | 1488000.000 | 0.000 | 46405926912 |
| 8gb | standard_onionpir | standard_onionpir | online_total_bytes | bytes | mixed | 1 | 26144.000 | 26144.000 | 26144.000 | 0.000 | 46405926912 |
| 8gb | standard_onionpir | standard_onionpir | query_upload_bytes | bytes | modeled | 1 | 14880.000 | 14880.000 | 14880.000 | 0.000 | 46405926912 |
| 8gb | standard_onionpir | standard_onionpir | response_download_bytes | bytes | actual | 1 | 11264.000 | 11264.000 | 11264.000 | 0.000 | 46405926912 |
| 8gb | standard_onionpir | standard_onionpir | server_compute_ms | ms | actual | 100 | 10518.811 | 10529.700 | 10562.184 | 31.189 | 46405926912 |
| 8gb | tree_g1 |  | helper_key_bytes | bytes | modeled | 1 | 1607040.000 | 1607040.000 | 1607040.000 | 0.000 | 4399472640 |
| 8gb | tree_g1 |  | online_total_bytes_mixed | bytes | mixed | 1 | 26144.000 | 26144.000 | 26144.000 | 0.000 | 4399472640 |
| 8gb | tree_g1 |  | query_upload_bytes | bytes | modeled | 1 | 14880.000 | 14880.000 | 14880.000 | 0.000 | 4399472640 |
| 8gb | tree_g1 |  | response_download_bytes | bytes | actual | 100 | 11264.000 | 11264.000 | 11264.000 | 0.000 | 4399472640 |
| 8gb | tree_g1 |  | server_total_ms | ms | actual | 100 | 1404.789 | 1403.991 | 1421.070 | 9.470 | 4399472640 |
| 8gb | tree_g32 |  | helper_key_bytes | bytes | modeled | 1 | 1607040.000 | 1607040.000 | 1607040.000 | 0.000 | 138146684928 |
| 8gb | tree_g32 |  | online_total_bytes_mixed | bytes | mixed | 1 | 26144.000 | 26144.000 | 26144.000 | 0.000 | 138146684928 |
| 8gb | tree_g32 |  | query_upload_bytes | bytes | modeled | 1 | 14880.000 | 14880.000 | 14880.000 | 0.000 | 138146684928 |
| 8gb | tree_g32 |  | response_download_bytes | bytes | actual | 100 | 11264.000 | 11264.000 | 11264.000 | 0.000 | 138146684928 |
| 8gb | tree_g32 |  | server_total_ms | ms | actual | 100 | 18992.701 | 18990.620 | 19052.811 | 36.597 | 138146684928 |
