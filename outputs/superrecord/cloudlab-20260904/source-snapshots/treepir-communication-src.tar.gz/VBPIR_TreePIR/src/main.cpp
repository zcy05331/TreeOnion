#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <unistd.h>
#include <vector>

#include "batchpirclient.h"
#include "batchpirparams.h"
#include "batchpirserver.h"
#include "pirparams.h"
#include "rapidjson/document.h"

using namespace std;
using namespace chrono;

namespace {

const unsigned int kDefaultTreeHeight = 10;
const unsigned int kChildren = 2;
const size_t kEntrySize = 32;
const char kColors[] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q',
                        'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '0', '1', '2', '3', '4', '5', '6', '7',
                        '8', '9'};
const char *kUpstreamCommit = "930063c5aefc441244abb4890fdf35383f3aa956";

struct Options {
    unsigned int height = kDefaultTreeHeight;
    string leaf_file;
    size_t warmups = 3;
    size_t trials = 100;
    string output = "-";
    bool validate_index_only = false;
};

struct ColorEntry {
    size_t color;
    size_t index;
    vector<unsigned char> bytes;
};

struct PreparedLeaf {
    uint64_t leaf_id;
    vector<uint64_t> path_nodes;
    vector<uint64_t> sub_indices;
    vector<vector<unsigned char>> expected_entries;
    double index_ms;
};

struct TrialResult {
    size_t ordinal;
    bool warmup;
    uint64_t leaf_id;
    vector<uint64_t> path_nodes;
    vector<uint64_t> sub_indices;
    double index_ms;
    double query_ms;
    double server_ms;
    double server_first_dimension_ms;
    double server_second_dimension_ms;
    double server_last_dimension_ms;
    double server_merge_ms;
    double response_serialize_ms;
    double decode_ms;
    size_t query_payload_bytes_bound_save_size_seeded_div2;
    size_t actual_response_payload_bytes;
    size_t query_ciphertexts;
    size_t response_ciphertexts;
    bool correct;
    size_t decoded_entries;
    double query_serialize_ms;
    size_t actual_query_payload_bytes_unseeded;
};

class ScopedCoutRedirect {
public:
    explicit ScopedCoutRedirect(ostream &target)
        : original_(cout.rdbuf(target.rdbuf()))
    {
    }

    ~ScopedCoutRedirect()
    {
        cout.rdbuf(original_);
    }

private:
    streambuf *original_;
};

struct NumColor {
    char color;
    uint64_t size;
};

uint64_t pow2(unsigned int exponent)
{
    if (exponent >= 63) {
        throw runtime_error("height is too large for uint64_t node ids");
    }
    return 1ULL << exponent;
}

uint64_t node_count_for_height(unsigned int height)
{
    return pow2(height + 1) - 2;
}

uint64_t leaf_count_for_height(unsigned int height)
{
    return pow2(height);
}

int color_index(char color)
{
    for (size_t i = 0; i < sizeof(kColors); ++i) {
        if (kColors[i] == color) {
            return static_cast<int>(i);
        }
    }
    throw runtime_error("unknown color");
}

void stable_sort_colors(vector<NumColor> &colors)
{
    stable_sort(colors.begin(), colors.end(), [](const NumColor &a, const NumColor &b) {
        return a.size < b.size;
    });
}

vector<NumColor> balanced_color_sequence(unsigned int height)
{
    uint64_t total_nodes = node_count_for_height(height);
    uint64_t base = total_nodes / height;
    uint64_t larger = total_nodes % height;
    vector<NumColor> colors;
    colors.reserve(height);
    for (unsigned int i = 0; i < height; ++i) {
        colors.push_back(NumColor{kColors[i], base + (i >= height - larger ? 1 : 0)});
    }
    stable_sort_colors(colors);
    return colors;
}

pair<vector<NumColor>, vector<NumColor>> feasible_split(unsigned int height, const vector<NumColor> &c)
{
    vector<NumColor> a;
    vector<NumColor> b;
    a.reserve(height - 1);
    b.reserve(height - 1);

    if (height == 2) {
        if (c[0].size == 2) {
            a.push_back(NumColor{c[1].color, c[1].size / 2});
            b.push_back(NumColor{c[1].color, c[1].size / 2});
        } else {
            a.push_back(NumColor{c[1].color, c[1].size - 1});
            b.push_back(NumColor{c[0].color, c[0].size - 1});
        }
    } else if (c[0].size == 2) {
        size_t i = 1;
        uint64_t a_value = c[i].size / 2;
        uint64_t b_value = (c[i].size + 1) / 2;
        a.push_back(NumColor{c[i].color, a_value});
        b.push_back(NumColor{c[i].color, b_value});
        uint64_t sa = a_value;
        uint64_t sb = b_value;
        ++i;
        while (i < height) {
            if (sa < sb) {
                a_value = (c[i].size + 1) / 2;
                b_value = c[i].size / 2;
            } else {
                a_value = c[i].size / 2;
                b_value = (c[i].size + 1) / 2;
            }
            a.push_back(NumColor{c[i].color, a_value});
            b.push_back(NumColor{c[i].color, b_value});
            sa += a_value;
            sb += b_value;
            ++i;
        }
    } else {
        size_t i = 1;
        uint64_t a_value = c[i].size - 1;
        uint64_t b_value = c[0].size - 1;
        a.push_back(NumColor{c[1].color, a_value});
        b.push_back(NumColor{c[0].color, b_value});
        uint64_t sa = a_value;
        uint64_t sb = b_value;
        ++i;
        a_value = (c[i].size + c[0].size - c[i - 1].size + 1) / 2;
        b_value = c[i - 1].size - c[0].size + (c[i].size + c[0].size - c[i - 1].size) / 2;
        a.push_back(NumColor{c[i].color, a_value});
        b.push_back(NumColor{c[i].color, b_value});
        sa += a_value;
        sb += b_value;
        ++i;
        while (i < height) {
            if (sa < sb) {
                a_value = (c[i].size + 1) / 2;
                b_value = c[i].size / 2;
            } else {
                a_value = c[i].size / 2;
                b_value = (c[i].size + 1) / 2;
            }
            a.push_back(NumColor{c[i].color, a_value});
            b.push_back(NumColor{c[i].color, b_value});
            sa += a_value;
            sb += b_value;
            ++i;
        }
    }

    stable_sort_colors(a);
    stable_sort_colors(b);
    return make_pair(a, b);
}

string join_path(const string &base, const string &suffix)
{
    if (base.empty() || base == ".") {
        return suffix;
    }
    if (base[base.size() - 1] == '/') {
        return base + suffix;
    }
    return base + "/" + suffix;
}

string current_working_dir()
{
    char buf[4096];
    if (getcwd(buf, sizeof(buf)) == nullptr) {
        throw runtime_error("unable to read current working directory");
    }
    return string(buf);
}

string data_dir()
{
    const char *env = getenv("TREEPIR_DATA_DIR");
    if (env != nullptr && env[0] != '\0') {
        return string(env);
    }
    return current_working_dir();
}

string read_text_file(const string &path)
{
    ifstream file(path.c_str());
    if (!file.is_open()) {
        throw runtime_error("unable to open file: " + path);
    }
    return string((istreambuf_iterator<char>(file)), istreambuf_iterator<char>());
}

rapidjson::Document parse_json_file(const string &path)
{
    string json = read_text_file(path);
    rapidjson::Document doc;
    doc.Parse(json.c_str());
    if (doc.HasParseError()) {
        throw runtime_error("JSON parse error in " + path);
    }
    return doc;
}

vector<unsigned char> hex_to_bytes(const string &hex, const string &label)
{
    if (hex.size() != kEntrySize * 2) {
        throw runtime_error(label + " has unexpected hex length");
    }
    vector<unsigned char> bytes;
    bytes.reserve(kEntrySize);
    for (size_t i = 0; i < hex.size(); i += 2) {
        string byte_string = hex.substr(i, 2);
        bytes.push_back(static_cast<unsigned char>(stoi(byte_string, nullptr, 16)));
    }
    return bytes;
}

string bytes_to_hex(const vector<unsigned char> &bytes)
{
    ostringstream out;
    out << hex << setfill('0');
    for (unsigned char byte : bytes) {
        out << setw(2) << static_cast<unsigned int>(byte);
    }
    return out.str();
}

unordered_map<uint64_t, vector<unsigned char>> load_whole_tree(const string &root, unsigned int height)
{
    string path = join_path(root, "treedata/WholeTree_" + to_string(height) + "_2.json");
    rapidjson::Document doc = parse_json_file(path);
    if (!doc.IsObject()) {
        throw runtime_error(path + " must contain a JSON object");
    }

    unordered_map<uint64_t, vector<unsigned char>> whole_tree;
    for (rapidjson::Value::ConstMemberIterator itr = doc.MemberBegin(); itr != doc.MemberEnd(); ++itr) {
        if (!itr->name.IsString() || !itr->value.IsString()) {
            throw runtime_error(path + " contains a non-string node entry");
        }
        uint64_t node_id = stoull(itr->name.GetString());
        whole_tree[node_id] = hex_to_bytes(itr->value.GetString(), "WholeTree node " + to_string(node_id));
    }

    const size_t expected_nodes = static_cast<size_t>(node_count_for_height(height));
    if (whole_tree.size() != expected_nodes) {
        throw runtime_error("WholeTree_10_2.json node count mismatch");
    }
    return whole_tree;
}

unordered_map<uint64_t, ColorEntry> load_color_index(
    const string &root,
    const unordered_map<uint64_t, vector<unsigned char>> &whole_tree,
    unsigned int height)
{
    unordered_map<uint64_t, ColorEntry> index;
    for (size_t color_idx = 0; color_idx < height; ++color_idx) {
        string filename = string("colorSubDB/color") + kColors[color_idx] + "_" + to_string(height) + "_2.json";
        string path = join_path(root, filename);
        rapidjson::Document doc = parse_json_file(path);
        if (!doc.IsArray() || doc.Size() != 1 || !doc[0].IsObject()) {
            throw runtime_error(path + " must contain one object inside an array");
        }

        size_t entry_index = 0;
        for (rapidjson::Value::ConstMemberIterator itr = doc[0].MemberBegin(); itr != doc[0].MemberEnd(); ++itr) {
            if (!itr->name.IsString() || !itr->value.IsString()) {
                throw runtime_error(path + " contains a non-string node entry");
            }
            uint64_t node_id = stoull(itr->name.GetString());
            vector<unsigned char> bytes = hex_to_bytes(itr->value.GetString(), filename + " node " + to_string(node_id));
            auto whole_it = whole_tree.find(node_id);
            if (whole_it == whole_tree.end()) {
                throw runtime_error(filename + " node " + to_string(node_id) + " is missing from WholeTree");
            }
            if (whole_it->second != bytes) {
                throw runtime_error(filename + " node " + to_string(node_id) + " does not match WholeTree");
            }
            if (index.find(node_id) != index.end()) {
                throw runtime_error("node " + to_string(node_id) + " appears in more than one color file");
            }
            index[node_id] = ColorEntry{color_idx, entry_index, bytes};
            ++entry_index;
        }
    }

    const size_t expected_nodes = static_cast<size_t>(node_count_for_height(height));
    if (index.size() != expected_nodes) {
        throw runtime_error("colorSubDB node coverage mismatch");
    }
    return index;
}

vector<uint64_t> path_nodes_for_leaf(unsigned int height, uint64_t leaf_id)
{
    const uint64_t leaf_count = leaf_count_for_height(height);
    if (leaf_id >= leaf_count) {
        throw runtime_error("leaf id " + to_string(leaf_id) + " is outside h" + to_string(height) + " leaf range");
    }

    vector<uint64_t> path;
    uint64_t node_id = leaf_count + leaf_id;
    for (size_t i = 0; i < height; ++i) {
        path.push_back(node_id);
        node_id /= 2;
    }
    reverse(path.begin(), path.end());
    return path;
}

vector<int> path_positions_for_leaf(unsigned int height, uint64_t leaf_id)
{
    vector<uint64_t> node_ids = path_nodes_for_leaf(height, leaf_id);
    vector<int> path;
    path.reserve(height);
    for (unsigned int level = 1; level <= height; ++level) {
        uint64_t first = pow2(level);
        int temp = static_cast<int>((node_ids[level - 1] - first + 1) % 2);
        path.push_back(temp == 0 ? 2 : temp);
    }
    return path;
}

vector<uint64_t> map_indices_for_leaf(unsigned int height, uint64_t leaf_id)
{
    vector<int> path = path_positions_for_leaf(height, leaf_id);
    vector<NumColor> c = balanced_color_sequence(height);
    vector<uint64_t> count(height, 0);
    vector<uint64_t> indices(height, 0);
    vector<bool> seen(height, false);

    for (unsigned int l = 0; l < height - 1; ++l) {
        unsigned int current_height = height - l;
        int x = (c[0].size == 2) ? 2 : 1;
        char root_col;

        if (path[l] <= x) {
            root_col = c[0].color;
            count[color_index(c[0].color)] += path[l] - 1;
            count[color_index(c[1].color)] += 2 - x;
            int idx = color_index(c[0].color);
            indices[idx] = count[idx];
            seen[idx] = true;
        } else {
            root_col = c[1].color;
            count[color_index(c[1].color)] += path[l] - x - 1;
            count[color_index(c[0].color)] += x;
            int idx = color_index(c[1].color);
            indices[idx] = count[idx];
            seen[idx] = true;
        }

        pair<vector<NumColor>, vector<NumColor>> split = feasible_split(current_height, c);
        const vector<NumColor> &a = split.first;
        const vector<NumColor> &b = split.second;

        if (path[l] == 2) {
            for (size_t i = 0; i < a.size(); ++i) {
                if (root_col != a[i].color) {
                    count[color_index(a[i].color)] += a[i].size;
                }
            }
        }

        c = (path[l] == 1) ? a : b;
        if (c.size() == 1) {
            int idx = color_index(c[0].color);
            count[idx] += path[path.size() - 1] - 1;
            indices[idx] = count[idx];
            seen[idx] = true;
        } else {
            stable_sort_colors(c);
        }
    }

    for (unsigned int i = 0; i < height; ++i) {
        if (!seen[i]) {
            throw runtime_error("indexing did not produce color " + string(1, kColors[i]));
        }
    }
    return indices;
}

PreparedLeaf prepare_leaf(
    unsigned int height,
    uint64_t leaf_id,
    const unordered_map<uint64_t, ColorEntry> *fixture_color_index)
{
    PreparedLeaf prepared;
    prepared.leaf_id = leaf_id;
    auto index_start = high_resolution_clock::now();
    prepared.path_nodes = path_nodes_for_leaf(height, leaf_id);
    prepared.sub_indices = map_indices_for_leaf(height, leaf_id);
    auto index_end = high_resolution_clock::now();
    prepared.index_ms = duration_cast<duration<double, milli>>(index_end - index_start).count();
    prepared.expected_entries.assign(height, vector<unsigned char>());

    if (fixture_color_index != nullptr) {
        set<size_t> seen_colors;
        for (uint64_t node_id : prepared.path_nodes) {
            auto it = fixture_color_index->find(node_id);
            if (it == fixture_color_index->end()) {
                throw runtime_error("path node " + to_string(node_id) + " missing from color index");
            }
            if (!seen_colors.insert(it->second.color).second) {
                throw runtime_error("leaf " + to_string(leaf_id) + " path has duplicate color");
            }
            if (prepared.sub_indices[it->second.color] != it->second.index) {
                throw runtime_error("generated h10 index does not match fixture for node " + to_string(node_id));
            }
            prepared.expected_entries[it->second.color] = it->second.bytes;
        }
        if (seen_colors.size() != height) {
            throw runtime_error("leaf " + to_string(leaf_id) + " path does not cover all colors");
        }
    } else {
        auto mix = [](uint64_t x) -> uint64_t {
            x += 0x9e3779b97f4a7c15ULL;
            x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
            x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
            return x ^ (x >> 31);
        };
        for (unsigned int color = 0; color < height; ++color) {
            uint64_t state = mix((static_cast<uint64_t>(height) << 48) ^ (static_cast<uint64_t>(color) << 40) ^ prepared.sub_indices[color]);
            vector<unsigned char> entry(kEntrySize);
            for (size_t i = 0; i < entry.size(); ++i) {
                if ((i % 8) == 0) {
                    state = mix(state + i);
                }
                entry[i] = static_cast<unsigned char>((state >> (8 * (i % 8))) & 0xff);
            }
            prepared.expected_entries[color] = entry;
        }
    }
    return prepared;
}

vector<uint64_t> read_leaf_ids(const string &path, size_t count)
{
    ifstream file(path.c_str());
    if (!file.is_open()) {
        throw runtime_error("unable to open leaf file: " + path);
    }

    vector<uint64_t> leaf_ids;
    string line;
    while (getline(file, line)) {
        if (line.empty()) {
            continue;
        }
        if (line[0] == '#') {
            continue;
        }
        leaf_ids.push_back(stoull(line));
        if (leaf_ids.size() == count) {
            break;
        }
    }
    if (leaf_ids.size() < count) {
        throw runtime_error("leaf file has fewer entries than warmups + trials");
    }
    return leaf_ids;
}

void validate_h10_fixture_against_generated_indices(
    const unordered_map<uint64_t, ColorEntry> &fixture_color_index,
    const string &root)
{
    const unsigned int height = 10;
    const uint64_t leaves = leaf_count_for_height(height);
    for (uint64_t leaf_id = 0; leaf_id < leaves; ++leaf_id) {
        vector<uint64_t> path_nodes = path_nodes_for_leaf(height, leaf_id);
        vector<uint64_t> indices = map_indices_for_leaf(height, leaf_id);
        for (uint64_t node_id : path_nodes) {
            auto it = fixture_color_index.find(node_id);
            if (it == fixture_color_index.end()) {
                throw runtime_error("generated h10 validation path node missing from fixture: " + to_string(node_id));
            }
            if (indices[it->second.color] != it->second.index) {
                throw runtime_error("generated h10 validation index mismatch at node " + to_string(node_id));
            }
        }
    }

    string golden_path = join_path(root, "subIndices/color_indices_10_2.txt");
    ifstream file(golden_path.c_str());
    if (!file.is_open()) {
        throw runtime_error("unable to open h10 golden index file: " + golden_path);
    }

    string line;
    uint64_t current_leaf_one_based = 0;
    size_t checked = 0;
    while (getline(file, line)) {
        if (line.find("TX_index: ") == 0) {
            current_leaf_one_based = stoull(line.substr(string("TX_index: ").size()));
            if (current_leaf_one_based == 0) {
                throw runtime_error("h10 golden uses invalid one-based TX_index 0");
            }
            continue;
        }
        size_t color_pos = line.find("color");
        size_t node_pos = line.find("; NodeID: ");
        size_t index_pos = line.find("; Index: ");
        if (color_pos == string::npos || node_pos == string::npos || index_pos == string::npos) {
            continue;
        }
        if (current_leaf_one_based == 0) {
            throw runtime_error("h10 golden color entry appears before TX_index");
        }
        char color = line[color_pos + 5];
        uint64_t node_id = stoull(line.substr(node_pos + string("; NodeID: ").size(), index_pos - (node_pos + string("; NodeID: ").size())));
        uint64_t index = stoull(line.substr(index_pos + string("; Index: ").size()));
        vector<uint64_t> generated_indices = map_indices_for_leaf(height, current_leaf_one_based - 1);
        vector<uint64_t> generated_nodes = path_nodes_for_leaf(height, current_leaf_one_based - 1);
        int idx = color_index(color);
        if (generated_indices[idx] != index) {
            throw runtime_error("h10 golden index mismatch for TX_index " + to_string(current_leaf_one_based) + " color " + string(1, color));
        }
        if (find(generated_nodes.begin(), generated_nodes.end(), node_id) == generated_nodes.end()) {
            throw runtime_error("h10 golden node is not on generated path for TX_index " + to_string(current_leaf_one_based));
        }
        ++checked;
    }
    if (checked == 0) {
        throw runtime_error("h10 golden index file had no checked entries");
    }
}

Options parse_options(int argc, char *argv[])
{
    Options options;
    for (int i = 1; i < argc; ++i) {
        string arg = argv[i];
        if (arg == "--height" && i + 1 < argc) {
            options.height = static_cast<unsigned int>(stoul(argv[++i]));
        } else if (arg == "--leaf-file" && i + 1 < argc) {
            options.leaf_file = argv[++i];
        } else if (arg == "--warmup" && i + 1 < argc) {
            options.warmups = stoull(argv[++i]);
        } else if (arg == "--trials" && i + 1 < argc) {
            options.trials = stoull(argv[++i]);
        } else if (arg == "--output" && i + 1 < argc) {
            options.output = argv[++i];
        } else if (arg == "--validate-index-only") {
            options.validate_index_only = true;
        } else {
            throw runtime_error("usage: vbpir_treepir --height 10|24|27 --leaf-file FILE [--warmup N] [--trials N] [--output FILE|-] [--validate-index-only]");
        }
    }
    if (options.height != 10 && options.height != 24 && options.height != 27) {
        throw runtime_error("--height must be 10, 24, or 27");
    }
    if (options.leaf_file.empty()) {
        throw runtime_error("--leaf-file is required");
    }
    if (options.trials == 0) {
        throw runtime_error("--trials must be greater than zero");
    }
    return options;
}

size_t query_payload_size_bound(const vector<PIRQuery> &queries)
{
    size_t total = 0;
    for (const auto &query_list : queries) {
        for (const auto &query : query_list) {
            total += static_cast<size_t>(query.save_size() / 2);
        }
    }
    return total;
}

size_t serialize_response_payload_uncompressed(const PIRResponseList &responses)
{
    size_t total = 0;
    for (const auto &response : responses) {
        ostringstream stream(ios::out | ios::binary);
        streamoff written = response.save(stream, seal::compr_mode_type::none);
        if (written < 0) {
            throw runtime_error("response ciphertext serialization failed");
        }
        total += static_cast<size_t>(written);
    }
    return total;
}

size_t serialize_query_payload_uncompressed(const vector<PIRQuery> &queries)
{
    size_t total = 0;
    for (const auto &part : queries) {
        total += serialize_response_payload_uncompressed(part);
    }
    return total;
}

bool check_correct(
    const vector<RawResponses> &decoded,
    const vector<vector<unsigned char>> &expected_entries,
    size_t *decoded_count)
{
    vector<string> actual;
    for (const auto &outer : decoded) {
        for (const auto &entry : outer) {
            actual.push_back(bytes_to_hex(entry));
        }
    }
    *decoded_count = actual.size();

    vector<string> expected;
    for (const auto &entry : expected_entries) {
        expected.push_back(bytes_to_hex(entry));
    }
    sort(actual.begin(), actual.end());
    sort(expected.begin(), expected.end());
    return actual == expected;
}

double elapsed_ms(high_resolution_clock::time_point start, high_resolution_clock::time_point end)
{
    return duration_cast<duration<double, milli>>(end - start).count();
}

void write_uint_array(ostream &out, const vector<uint64_t> &values)
{
    out << "[";
    for (size_t i = 0; i < values.size(); ++i) {
        if (i != 0) {
            out << ",";
        }
        out << values[i];
    }
    out << "]";
}

string json_escape(const string &value)
{
    ostringstream out;
    for (char ch : value) {
        switch (ch) {
            case '\\': out << "\\\\"; break;
            case '"': out << "\\\""; break;
            case '\n': out << "\\n"; break;
            case '\r': out << "\\r"; break;
            case '\t': out << "\\t"; break;
            default: out << ch; break;
        }
    }
    return out.str();
}

void write_json(
    ostream &out,
    const Options &options,
    const string &root,
    double index_prep_ms,
    const vector<TrialResult> &results,
    double offline_setup_ms = 0.0,
    size_t actual_helper_key_bytes = 0)
{
    size_t measured_count = 0;
    double measured_index_ms = 0.0;
    double measured_query_ms = 0.0;
    double measured_server_ms = 0.0;
    double measured_first_ms = 0.0;
    double measured_second_ms = 0.0;
    double measured_last_ms = 0.0;
    double measured_merge_ms = 0.0;
    double measured_response_serialize_ms = 0.0;
    double measured_decode_ms = 0.0;
    double measured_actual_response_payload_bytes = 0.0;
    bool all_correct = true;
    for (const auto &r : results) {
        all_correct = all_correct && r.correct;
        if (!r.warmup) {
            ++measured_count;
            measured_index_ms += r.index_ms;
            measured_query_ms += r.query_ms;
            measured_server_ms += r.server_ms;
            measured_first_ms += r.server_first_dimension_ms;
            measured_second_ms += r.server_second_dimension_ms;
            measured_last_ms += r.server_last_dimension_ms;
            measured_merge_ms += r.server_merge_ms;
            measured_response_serialize_ms += r.response_serialize_ms;
            measured_decode_ms += r.decode_ms;
            measured_actual_response_payload_bytes += r.actual_response_payload_bytes;
        }
    }
    if (measured_count != 0) {
        measured_index_ms /= measured_count;
        measured_query_ms /= measured_count;
        measured_server_ms /= measured_count;
        measured_first_ms /= measured_count;
        measured_second_ms /= measured_count;
        measured_last_ms /= measured_count;
        measured_merge_ms /= measured_count;
        measured_response_serialize_ms /= measured_count;
        measured_decode_ms /= measured_count;
        measured_actual_response_payload_bytes /= measured_count;
    }

    out << fixed << setprecision(3);
    out << "{";
    out << "\"model\":\"SEAL+VBPIRTreePIR\",";
    out << "\"upstream_commit\":\"" << kUpstreamCommit << "\",";
    out << "\"data_dir\":\"" << json_escape(root) << "\",";
    out << "\"leaf_file\":\"" << json_escape(options.leaf_file) << "\",";
    out << "\"height\":" << options.height << ",";
    out << "\"leaf_count\":" << leaf_count_for_height(options.height) << ",";
    out << "\"data_mode\":\"" << (options.height == 10 ? "fixture_json_validated" : "synthetic_balanced_color_buckets") << "\",";
    out << "\"entry_size_bytes\":" << kEntrySize << ",";
    uint64_t max_bucket_size = (node_count_for_height(options.height) + options.height - 1) / options.height;
    size_t first_dimension = max_bucket_size <= 104858 ? 64 : utils::next_power_of_two(std::ceil(std::cbrt(static_cast<double>(max_bucket_size))));
    out << "\"layout\":{";
    out << "\"color_buckets\":" << options.height << ",";
    out << "\"max_bucket_entries\":" << max_bucket_size << ",";
    out << "\"first_two_dimensions\":" << first_dimension << ",";
    out << "\"pir_shape\":\"" << first_dimension << "x" << first_dimension << "xceil(max_bucket/(d*d))\"";
    out << "},";
    out << "\"warmups\":" << options.warmups << ",";
    out << "\"trials\":" << options.trials << ",";
    out << "\"validate_index_only\":" << (options.validate_index_only ? "true" : "false") << ",";
    out << "\"index_prep_ms_excluded\":" << index_prep_ms << ",";
    out << "\"offline_setup_ms\":" << offline_setup_ms << ",";
    out << "\"actual_helper_key_bytes_uncompressed\":" << actual_helper_key_bytes << ",";
    out << "\"indexing_validation\":\"h10 C++ SubIndices port checked against all fixture path nodes and color_indices_10_2.txt; h24/h27 reuse the same port with range checks\",";
    out << "\"stage_definitions\":{";
    out << "\"index_ms\":\"per-leaf path_nodes_for_leaf plus map_indices_for_leaf; excludes h10 fixture load/validation and expected-entry setup\",";
    out << "\"query_ms\":\"client create_queries\",";
    out << "\"query_serialize_ms\":\"uncompressed expanded query ciphertext serialization after decode, outside query and server timing\",";
    out << "\"server_first_dimension_ms\":\"sum over PIR servers of process_first_dimension_delayed_mod\",";
    out << "\"server_second_dimension_ms\":\"sum over PIR servers of process_second_dimension or passthrough for 2D\",";
    out << "\"server_last_dimension_ms\":\"sum over PIR servers of process_last_dimension\",";
    out << "\"server_merge_ms\":\"merge_responses_chunks_buckets across color buckets\",";
    out << "\"server_ms\":\"full BatchPIRServer generate_response wall time including stages and merge\",";
    out << "\"response_serialize_ms\":\"SEAL Ciphertext::save to uncompressed in-memory streams, outside server and decode timers\",";
    out << "\"decode_ms\":\"client decode_responses_chunks only; correctness comparison happens after this timer\"";
    out << "},";
    out << "\"seal_parameters\":{";
    out << "\"scheme\":\"BFV\",";
    out << "\"poly_modulus_degree\":8192,";
    out << "\"coeff_modulus_bits\":[42,58,58,60],";
    out << "\"plain_modulus_bits\":28";
    out << "},";
    out << "\"communication_size_labels\":{";
    out << "\"query\":\"seeded save_size/2 model plus separately measured actual unseeded ciphertext payload; these are different encodings\",";
    out << "\"helper_keys\":\"actual GaloisKeys and RelinKeys save bytes, uncompressed, once per session\",";
    out << "\"response\":\"actual bytes returned by Ciphertext::save(compr_mode_type::none) to in-memory streams\"";
    out << "},";
    out << "\"serialization_timing\":\"query and response save uncompressed in memory, outside server timing\",";
    out << "\"measured_summary\":{";
    out << "\"count\":" << measured_count << ",";
    out << "\"index_ms_mean\":" << measured_index_ms << ",";
    out << "\"query_ms_mean\":" << measured_query_ms << ",";
    out << "\"server_ms_mean\":" << measured_server_ms << ",";
    out << "\"server_first_dimension_ms_mean\":" << measured_first_ms << ",";
    out << "\"server_second_dimension_ms_mean\":" << measured_second_ms << ",";
    out << "\"server_last_dimension_ms_mean\":" << measured_last_ms << ",";
    out << "\"server_merge_ms_mean\":" << measured_merge_ms << ",";
    out << "\"response_serialize_ms_mean\":" << measured_response_serialize_ms << ",";
    out << "\"decode_ms_mean\":" << measured_decode_ms << ",";
    out << "\"actual_response_payload_bytes_mean\":" << measured_actual_response_payload_bytes << ",";
    out << "\"all_correct\":" << (all_correct ? "true" : "false");
    out << "},";
    out << "\"results\":[";
    for (size_t i = 0; i < results.size(); ++i) {
        const TrialResult &r = results[i];
        if (i != 0) {
            out << ",";
        }
        out << "{";
        out << "\"iteration\":" << r.ordinal << ",";
        out << "\"phase\":\"" << (r.warmup ? "warmup" : "measured") << "\",";
        out << "\"leaf_id\":" << r.leaf_id << ",";
        out << "\"path_nodes\":";
        write_uint_array(out, r.path_nodes);
        out << ",\"sub_indices\":";
        write_uint_array(out, r.sub_indices);
        out << ",\"index_ms\":" << r.index_ms << ",";
        out << "\"query_ms\":" << r.query_ms << ",";
        out << "\"query_serialize_ms\":" << r.query_serialize_ms << ",";
        out << "\"actual_query_payload_bytes_unseeded\":" << r.actual_query_payload_bytes_unseeded << ",";
        out << "\"server_ms\":" << r.server_ms << ",";
        out << "\"server_first_dimension_ms\":" << r.server_first_dimension_ms << ",";
        out << "\"server_second_dimension_ms\":" << r.server_second_dimension_ms << ",";
        out << "\"server_last_dimension_ms\":" << r.server_last_dimension_ms << ",";
        out << "\"server_merge_ms\":" << r.server_merge_ms << ",";
        out << "\"response_serialize_ms\":" << r.response_serialize_ms << ",";
        out << "\"decode_ms\":" << r.decode_ms << ",";
        out << "\"query_payload_bytes_bound_save_size_seeded_div2\":" << r.query_payload_bytes_bound_save_size_seeded_div2 << ",";
        out << "\"actual_response_payload_bytes\":" << r.actual_response_payload_bytes << ",";
        out << "\"query_ciphertexts\":" << r.query_ciphertexts << ",";
        out << "\"response_ciphertexts\":" << r.response_ciphertexts << ",";
        out << "\"decoded_entries\":" << r.decoded_entries << ",";
        out << "\"correct\":" << (r.correct ? "true" : "false");
        out << "}";
    }
    out << "]}";
}

int run_benchmark(int argc, char *argv[])
{
    Options options = parse_options(argc, argv);
    const size_t total_iterations = options.warmups + options.trials;
    const string root = data_dir();

    auto prep_start = high_resolution_clock::now();
    unordered_map<uint64_t, ColorEntry> color_index;
    unordered_map<uint64_t, ColorEntry> *fixture_color_index = nullptr;
    if (options.height == 10) {
        auto whole_tree = load_whole_tree(root, options.height);
        color_index = load_color_index(root, whole_tree, options.height);
        validate_h10_fixture_against_generated_indices(color_index, root);
        fixture_color_index = &color_index;
    }
    vector<uint64_t> leaf_ids = read_leaf_ids(options.leaf_file, total_iterations);
    vector<PreparedLeaf> prepared_leaves;
    prepared_leaves.reserve(leaf_ids.size());
    for (uint64_t leaf_id : leaf_ids) {
        PreparedLeaf prepared = prepare_leaf(options.height, leaf_id, fixture_color_index);
        uint64_t max_bucket_size = (node_count_for_height(options.height) + options.height - 1) / options.height;
        for (size_t color = 0; color < prepared.sub_indices.size(); ++color) {
            if (prepared.sub_indices[color] >= max_bucket_size) {
                throw runtime_error("generated sub-index is outside color bucket range");
            }
        }
        prepared_leaves.push_back(prepared);
    }
    auto prep_end = high_resolution_clock::now();
    double index_prep_ms = elapsed_ms(prep_start, prep_end);

    if (options.validate_index_only) {
        ostringstream json;
        vector<TrialResult> index_results;
        index_results.reserve(prepared_leaves.size());
        for (size_t i = 0; i < prepared_leaves.size(); ++i) {
            const PreparedLeaf &leaf = prepared_leaves[i];
            index_results.push_back(TrialResult{
                i + 1,
                i < options.warmups,
                leaf.leaf_id,
                leaf.path_nodes,
                leaf.sub_indices,
                leaf.index_ms,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0,
                0,
                0,
                0,
                true,
                0});
        }
        write_json(json, options, root, index_prep_ms, index_results);
        if (options.output == "-") {
            cout << json.str() << endl;
        } else {
            ofstream file(options.output.c_str());
            if (!file.is_open()) {
                throw runtime_error("unable to open output file: " + options.output);
            }
            file << json.str() << endl;
            cout << json.str() << endl;
        }
        return 0;
    }

    const size_t num_nodes = static_cast<size_t>(node_count_for_height(options.height));
    const string selection = to_string(options.height) + "," + to_string(num_nodes) + "," + to_string(kEntrySize);
    const uint32_t client_id = 0;
    vector<TrialResult> results;
    results.reserve(total_iterations);
    double offline_setup_ms = 0.0;
    size_t actual_helper_key_bytes = 0;
    {
        ScopedCoutRedirect redirect(cerr);
        auto setup_start = high_resolution_clock::now();
        auto encryption_params = utils::create_encryption_parameters(selection);
        BatchPirParams params(options.height, num_nodes, kEntrySize, encryption_params);

        BatchPIRServer batch_server(options.height, kChildren, params, options.height != 10);
        BatchPIRClient batch_client(options.height, kChildren, params);
        auto public_keys = batch_client.get_public_keys();
        batch_server.set_client_keys(client_id, public_keys);
        offline_setup_ms = elapsed_ms(setup_start, high_resolution_clock::now());
        ostringstream key_stream(ios::out | ios::binary);
        actual_helper_key_bytes = static_cast<size_t>(public_keys.first.save(key_stream, seal::compr_mode_type::none));
        actual_helper_key_bytes += static_cast<size_t>(public_keys.second.save(key_stream, seal::compr_mode_type::none));

        for (size_t i = 0; i < prepared_leaves.size(); ++i) {
            const PreparedLeaf &leaf = prepared_leaves[i];
            auto query_start = high_resolution_clock::now();
            auto queries = batch_client.create_queries(leaf.sub_indices);
            auto query_end = high_resolution_clock::now();

            auto server_start = high_resolution_clock::now();
            BatchServerProfile server_profile;
            PIRResponseList responses = batch_server.generate_response(client_id, queries, &server_profile);
            auto server_end = high_resolution_clock::now();

            auto response_serialize_start = high_resolution_clock::now();
            size_t actual_response_payload_bytes = serialize_response_payload_uncompressed(responses);
            auto response_serialize_end = high_resolution_clock::now();

            auto decode_start = high_resolution_clock::now();
            auto decoded = batch_client.decode_responses_chunks(responses);
            auto decode_end = high_resolution_clock::now();

            auto query_serialize_start = high_resolution_clock::now();
            size_t actual_query_payload_bytes = serialize_query_payload_uncompressed(queries);
            auto query_serialize_end = high_resolution_clock::now();

            size_t decoded_count = 0;
            bool correct = check_correct(decoded, leaf.expected_entries, &decoded_count);
            if (!correct) throw runtime_error("decoded TreePIR path mismatch at leaf " + to_string(leaf.leaf_id));
            size_t query_count = 0;
            for (const auto &part : queries) query_count += part.size();

            results.push_back(TrialResult{
                i + 1,
                i < options.warmups,
                leaf.leaf_id,
                leaf.path_nodes,
                leaf.sub_indices,
                leaf.index_ms,
                elapsed_ms(query_start, query_end),
                elapsed_ms(server_start, server_end),
                server_profile.process_first_dimension_ms,
                server_profile.process_second_dimension_ms,
                server_profile.process_last_dimension_ms,
                server_profile.merge_ms,
                elapsed_ms(response_serialize_start, response_serialize_end),
                elapsed_ms(decode_start, decode_end),
                query_payload_size_bound(queries),
                actual_response_payload_bytes,
                query_count,
                responses.size(),
                correct,
                decoded_count,
                elapsed_ms(query_serialize_start, query_serialize_end),
                actual_query_payload_bytes});
        }
    }

    ostringstream json;
    write_json(json, options, root, index_prep_ms, results, offline_setup_ms, actual_helper_key_bytes);
    if (options.output == "-") {
        cout << json.str() << endl;
    } else {
        ofstream file(options.output.c_str());
        if (!file.is_open()) {
            throw runtime_error("unable to open output file: " + options.output);
        }
        file << json.str() << endl;
        cout << json.str() << endl;
    }
    return 0;
}

} // namespace

int main(int argc, char *argv[])
{
    try {
        return run_benchmark(argc, argv);
    } catch (const exception &e) {
        cerr << "TreePIR benchmark error: " << e.what() << endl;
        return 1;
    }
}
