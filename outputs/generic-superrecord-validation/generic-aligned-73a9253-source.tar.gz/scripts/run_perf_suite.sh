#!/bin/bash
# =============================================================================
# run_perf_suite.sh — 一键式全协议性能测试: 每种协议 x {1GB, 4GB} DB x 64 次
#   (唯一例外: merkle 的 4GB 档经 --run-optional-4gb 触发, 套件内固定 4 次测量)
#
# 一键跑全部(默认即此, 无需参数):
#   scripts/run_perf_suite.sh
#
# 覆盖的协议模式("每一种"):
#   merkle    merkle_benchmarks 套件: standard OnionPIR + flat + layerwise。
#             一次调用同时产出 1GB(2^24 叶, 主档, --experiments 次)与
#             4GB(2^26 叶, --run-optional-4gb, 固定 4 次测量,
#             套件自带 物理内存+2GB 安全门)两档。
#   tree      tree_bench_g32: Tree PIR MVP, 32 字节节点。
#   tree-g1   tree_bench: g=1 标量 MVP(诊断性基准, 叶数与各档对齐,
#             但每节点只有 12bit, 载荷字节数不等于 1GB/4GB, 报告里注意)。
#   compress  tree_compress: M7 小环压缩门(固定小形状, 无 DB 档位, 只跑一次)。
#   cuckoo    cuckoo_bench: cuckoo hash batch PIR baseline(3 hash, 1.5x 桶,
#             3x 复制)。
#   superrecord tree_superrecord_bench: 通用 super-record 树 PIR(规划器按
#             256 位条目枚举 (h,G,P,N0,b,h_q) 候选, 一次跑 Bundle3、h=1 对照与
#             Pareto 前沿), 同一进程内附带 legacy g=32 对照(同一叶调度)。
#             旋钮: SUPERRECORD_MAX_FRONTIER SUPERRECORD_MAX_ARITY
#             SUPERRECORD_SKIP_LEGACY=1。
# tree/tree-g1/cuckoo 的树高、次数与种子都是运行时旗标
# (--leaf-count/--experiments/--warmup/--trial-seed), 二进制与档位无关,
# 全套只构建一次; 同一 TRIAL_SEED 驱动 merkle 与这三种基准的查询调度。
#
# 旋钮(环境变量):
#   EXPERIMENTS=64  每种的测量次数        WARMUPS=3
#   SCALES="1gb 4gb"  只想跑一档可设 SCALES=1gb; 另有 256mb 档(2^22 叶, L=22,
#                     笔记本可跑的规模): SCALES=256mb EXPERIMENTS=16
#   TRIAL_SEED=5723628103747520850(与已提交结果同种子)
#   JOBS=<nproc>    NOAVX512=OFF
#   SKIP_BUILD=0    =1 时复用 build-perf-suite/Onion-PIR 不重建
#                   (须与当前检出一致, 00_meta.txt 记录的 commit 以此为准)
#
# 异机准备:
#   1) git clone <repo> && cd OnionPIRv2 && git checkout <分支/commit>
#   2) 需要 cmake>=3.13、C++20 编译器(gcc>=13 / 近年 clang)、git;
#      HEXL 依赖自动 clone(intel/hexl v1.2.6)装进 hexl_install/(gitignored;
#      无外网可从同 OS+同架构机器拷贝该目录, 已存在即跳过)
#   3) 内存: 4GB 档的 flat 基线与 tree MVP 峰值都远超 4GB(系数展开 ~5-16x),
#      merkle 套件自带内存门, tree/cuckoo 由本脚本粗估门控, 不够则记 skip;
#      tree 4GB 档(L=26)粗估峰值 ~66GB, 需要大内存服务器
#   4) 时长量级(参考 M4): flat 1GB 档 ~80s/次 x 67 ≈ 1.5h; 4GB 档虽 4 倍/次
#      但只测 4 次, 反而更短;
#      预留过夜时间, 建议 nohup/tmux 里跑
#
# 架构(强制 HEXL): Linux/macOS x86_64 原生; Apple Silicon 走 Rosetta;
#   其他架构直接报错(HEXL 是 x86 intrinsics 库, 无法给出可比数字)。
#
# 产出: outputs/perf/<机器>_<短commit>_<UTC>/
#   00_meta.txt 00_cpu.txt 00_status.txt cpu_info.txt
#   merkle.txt merkle.json(内含 1GB 与 4GB 两档 case)
#   tree_g32_{1gb,4gb}.txt tree_g1_{1gb,4gb}.txt cuckoo_{1gb,4gb}.txt
#   superrecord_{1gb,4gb}.txt compress.txt
# 完整性: 00_status.txt 每行 "<单元> ok|fail|skip [原因]"。任一单元失败
#   退出码 1; 全部通过但有请求的单元被资源门跳过(矩阵不完整)退出码 3;
#   只有全部单元 ok 才退出 0。单元失败不中断其余单元。
# =============================================================================
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${PROJECT_DIR}"

# ---------------- 旋钮 ----------------
EXPERIMENTS="${EXPERIMENTS:-64}"
WARMUPS="${WARMUPS:-3}"
TRIAL_SEED="${TRIAL_SEED:-5723628103747520850}"
BENCHMARK_CASE="${BENCHMARK_CASE:-all}"
SCALES="${SCALES:-1gb 4gb}"
NOAVX512="${NOAVX512:-OFF}"
SKIP_BUILD="${SKIP_BUILD:-0}"
ACTIVE_CONFIG="${ACTIVE_CONFIG:-CONFIG_N2048_K1_COMP}"
HEXL_VERSION="1.2.6"

scale_leaf_pow() {  # 档位 -> log2(叶数): 与套件的 paper_row 标签一致
  case "$1" in
    256mb) echo 22 ;;
    1gb) echo 24 ;;
    4gb) echo 26 ;;
    *) echo "未知档位 $1(可选 256mb 1gb 4gb)" >&2; exit 2 ;;
  esac
}

# ---------------- 平台探测(强制 HEXL, 非 x86_64 只认 Rosetta) ----------------
OS="$(uname -s)"
ARCH="$(uname -m)"
ROSETTA=0
CXX_LAUNCH=()
CMAKE_ARCH_FLAGS=()
if [[ "${OS}" == "Darwin" && "${ARCH}" == "arm64" ]]; then
  ROSETTA=1
  CXX_LAUNCH=(/usr/bin/arch -x86_64)
  CMAKE_ARCH_FLAGS=(
    -DCMAKE_OSX_ARCHITECTURES=x86_64
    '-DCMAKE_CXX_COMPILER=/usr/bin/arch;-x86_64;/usr/bin/clang++'
  )
elif [[ "${ARCH}" != "x86_64" ]]; then
  echo "错误: 本套件要求启用 HEXL, 而 HEXL 只支持 x86_64(当前 ${OS}/${ARCH})." >&2
  echo "请换用 x86_64 机器, 或 Apple Silicon Mac(自动走 Rosetta)." >&2
  exit 1
fi

if [[ "${OS}" == "Linux" ]]; then
  DEFAULT_JOBS="$(nproc 2>/dev/null || echo 4)"
  MEM_BYTES="$(awk '/^MemTotal/{print $2*1024}' /proc/meminfo 2>/dev/null || echo 0)"
else
  DEFAULT_JOBS="$(sysctl -n hw.ncpu 2>/dev/null || echo 4)"
  MEM_BYTES="$(sysctl -n hw.memsize 2>/dev/null || echo 0)"
fi
JOBS="${JOBS:-${DEFAULT_JOBS}}"

# ---------------- 依赖: Intel HEXL(仓库本地安装, gitignored) ----------------
HEXL_PREFIX="${PROJECT_DIR}/hexl_install"
HEXL_CMAKE_DIR="${HEXL_PREFIX}/lib64/cmake/hexl-${HEXL_VERSION}"
if [[ ! -d "${HEXL_CMAKE_DIR}" ]]; then
  echo "==> 未找到 hexl_install/, 自动构建 Intel HEXL v${HEXL_VERSION}"
  HEXL_SRC="${PROJECT_DIR}/.deps/hexl-src"
  if [[ ! -d "${HEXL_SRC}" ]]; then
    mkdir -p "${PROJECT_DIR}/.deps"
    git clone --depth 1 -b "v${HEXL_VERSION}" \
        https://github.com/intel/hexl.git "${HEXL_SRC}" \
      || git clone --depth 1 -b "${HEXL_VERSION}" \
        https://github.com/intel/hexl.git "${HEXL_SRC}"
  fi
  cmake -S "${HEXL_SRC}" -B "${PROJECT_DIR}/.deps/hexl-build" \
    ${CMAKE_ARCH_FLAGS[@]+"${CMAKE_ARCH_FLAGS[@]}"} \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_INSTALL_PREFIX="${HEXL_PREFIX}" \
    -DCMAKE_INSTALL_LIBDIR=lib64 \
    -DHEXL_BENCHMARK=OFF -DHEXL_TESTING=OFF
  cmake --build "${PROJECT_DIR}/.deps/hexl-build" -j"${JOBS}"
  cmake --install "${PROJECT_DIR}/.deps/hexl-build"
  test -d "${HEXL_CMAKE_DIR}" || {
    echo "HEXL 安装后未见 ${HEXL_CMAKE_DIR}" >&2; exit 1; }
fi

# 粗估内存门(单位: 字节)。tree MVP: canonical u64 系数 + m32 视图合计约
# 2^(L+10)(L=22 实测 ~4GB 量级外推); cuckoo: 3 hash 复制 + 稠密打包同量级。
# 不够(含 2GB 余量)则跳过该档并记录原因, 避免过夜 OOM 白跑。
mem_gate() {  # mem_gate <单元> <所需字节> -> 0 通过; 否则记 skip 并返回 1
  local unit="$1" need="$2"
  local margin=$((2 << 30))
  if [[ "${MEM_BYTES}" -gt 0 && $((need + margin)) -gt "${MEM_BYTES}" ]]; then
    echo "[skip] ${unit}: 粗估峰值 ${need}B + 2GB 余量 > 物理内存 ${MEM_BYTES}B" >&2
    record "${unit}" skip "peak_estimate=${need}B mem=${MEM_BYTES}B"
    return 1
  fi
  return 0
}

# ---------------- 构建(一次; 档位是运行时旗标) ----------------
BUILD_DIR="${PROJECT_DIR}/build-perf-suite"
BINARY="${BUILD_DIR}/Onion-PIR"
build_binary() {
  [[ "${SKIP_BUILD}" == "1" ]] && return 0
  local args=(
    -S "${PROJECT_DIR}" -B "${BUILD_DIR}"
    -DCMAKE_BUILD_TYPE=Benchmark
    -DACTIVE_CONFIG="${ACTIVE_CONFIG}"
    -DUSE_HEXL=ON
    -DHEXL_DIR="${HEXL_CMAKE_DIR}"
    -DNOAVX512="${NOAVX512}"
  )
  if [[ ${#CMAKE_ARCH_FLAGS[@]} -gt 0 ]]; then
    args+=("${CMAKE_ARCH_FLAGS[@]}")
  fi
  # --fresh 防旧缓存; cmake<3.24 无此旗标则清缓存重试
  cmake --fresh "${args[@]}" 2>/dev/null \
    || { rm -rf "${BUILD_DIR}/CMakeCache.txt" "${BUILD_DIR}/CMakeFiles"; \
         cmake "${args[@]}"; }
  cmake --build "${BUILD_DIR}" -j"${JOBS}"
}

# ---------------- 结果目录与机器元数据 ----------------
COMMIT="$(git rev-parse HEAD)"
SHORT_COMMIT="$(git rev-parse --short=12 HEAD)"
BRANCH="$(git branch --show-current || echo detached)"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
HOST_TAG="$(hostname -s | tr '[:upper:]' '[:lower:]' | tr -c 'a-z0-9\n' '-')"
OUT_DIR="${PROJECT_DIR}/outputs/perf/${HOST_TAG}_${SHORT_COMMIT}_${STAMP}"
mkdir -p "${OUT_DIR}"
STATUS_FILE="${OUT_DIR}/00_status.txt"
: > "${STATUS_FILE}"
FAIL_COUNT=0
SKIP_COUNT=0
record() {  # record <单元> ok|fail|skip [原因]
  echo "$1 $2${3:+ $3}" >> "${STATUS_FILE}"
  case "$2" in
    fail) FAIL_COUNT=$((FAIL_COUNT + 1)) ;;
    skip) SKIP_COUNT=$((SKIP_COUNT + 1)) ;;
  esac
}

if [[ "${OS}" == "Linux" ]]; then
  CPU_METADATA="$(awk -F': *' '/^model name/{print $2; exit}' /proc/cpuinfo)"
  lscpu > "${OUT_DIR}/00_cpu.txt" 2>&1 || true
  OS_METADATA="$(uname -a)"
else
  CPU_METADATA="$(sysctl -n machdep.cpu.brand_string)"
  sysctl machdep.cpu hw.ncpu hw.memsize > "${OUT_DIR}/00_cpu.txt" 2>&1 || true
  OS_METADATA="$(sw_vers | tr '\n' ';')"
fi
COMPILER_METADATA="$(${CXX_LAUNCH[@]+"${CXX_LAUNCH[@]}"} \
  "${CXX:-c++}" --version 2>/dev/null | sed -n 1p || echo unknown)"
CMAKE_METADATA="$(cmake --version | sed -n 1p)"

{
  echo "commit:      ${COMMIT} (${BRANCH})"
  echo "utc:         ${STAMP}"
  echo "os:          ${OS_METADATA}"
  echo "cpu:         ${CPU_METADATA}  mem=${MEM_BYTES}B"
  echo "arch:        ${ARCH} rosetta=${ROSETTA}"
  echo "compiler:    ${COMPILER_METADATA}"
  echo "cmake:       ${CMAKE_METADATA}"
  echo "hexl:        ${HEXL_CMAKE_DIR} NOAVX512=${NOAVX512}"
  echo "config:      ${ACTIVE_CONFIG}"
  echo "knobs:       trials=${EXPERIMENTS} warmup=${WARMUPS}" \
       "seed=${TRIAL_SEED} scales='${SCALES}' case=${BENCHMARK_CASE}" \
       "skip_build=${SKIP_BUILD}"
  git status --short
} > "${OUT_DIR}/00_meta.txt"

run_bin() {  # run_bin <日志名> <参数...>; 单元名 = 日志名去 .txt; 失败不终止套件
  local log="${OUT_DIR}/$1"; local unit="${1%.txt}"; shift
  echo "==> $* | tee ${log}"
  if ${CXX_LAUNCH[@]+"${CXX_LAUNCH[@]}"} "${BINARY}" "$@" 2>&1 | tee "${log}"; then
    record "${unit}" ok
  else
    echo "[fail] ${unit}: 退出非零, 详见 ${log}(套件继续)" >&2
    record "${unit}" fail "log=$(basename "${log}")"
  fi
}

# ---------------- 模式选择 ----------------
MODES=("$@")
if [[ ${#MODES[@]} -eq 0 ]]; then
  MODES=(merkle tree tree-g1 compress cuckoo superrecord)
fi
has_mode() { local m; for m in "${MODES[@]}"; do [[ "$m" == "$1" ]] && return 0; done; return 1; }
for MODE in "${MODES[@]}"; do
  case "${MODE}" in merkle|tree|tree-g1|compress|cuckoo|superrecord) ;;
    *) echo "未知模式: ${MODE}(可选 merkle tree tree-g1 compress cuckoo superrecord)" >&2; exit 2 ;;
  esac
done

# merkle 主档叶数取 SCALES 的首个档位; 套件把主档上限设在 2^24, 4gb 只能经
# --run-optional-4gb 追加, 所以 SCALES 必须以 256mb 或 1gb 开头。
read -ra SCALE_LIST <<< "${SCALES}"
PRIMARY_POW="$(scale_leaf_pow "${SCALE_LIST[0]}")"
if [[ "${PRIMARY_POW}" -gt 24 ]]; then
  echo "merkle 主档上限 2^24: SCALES 需以 256mb 或 1gb 开头(4gb 经 flag 追加)" >&2
  exit 2
fi
WANT_4GB=0
case " ${SCALES} " in *" 4gb "*) WANT_4GB=1 ;; esac

# ---------------- 构建一次 ----------------
build_binary
test -x "${BINARY}" || { echo "缺少 ${BINARY}" >&2; exit 1; }
if [[ "${ROSETTA}" == "1" ]]; then
  file "${BINARY}" | grep -q 'x86_64' || { echo "二进制不是 x86_64" >&2; exit 1; }
fi

# ---------------- 执行 ----------------
run_bin cpu_info.txt --test cpu_info

# merkle 套件一次调用覆盖两档: 主档 = SCALES 首个档位(256mb/1gb,
# --experiments 次), SCALES 含 4gb 时加 --run-optional-4gb 让同一进程再测
# 2^26 档(套件内固定 4 次测量, 内存不够则套件自记 skipped_resource_limit,
# 本脚本从 merkle.json 读回该状态计入 00_status.txt)
if has_mode merkle; then
  MERKLE_ARGS=(--test merkle_benchmarks
    --leaf-count $((1 << PRIMARY_POW)) --warmup "${WARMUPS}"
    --experiments "${EXPERIMENTS}" --trial-seed "${TRIAL_SEED}"
    --benchmark-case "${BENCHMARK_CASE}"
    --benchmark-json "${OUT_DIR}/merkle.json")
  [[ "${WANT_4GB}" == "1" ]] && MERKLE_ARGS+=(--run-optional-4gb)
  ONIONPIR_BENCH_COMMIT="${COMMIT}" \
  ONIONPIR_BENCH_BRANCH="${BRANCH}" \
  ONIONPIR_BENCH_PROCESS_ARCH="${ARCH}" \
  ONIONPIR_BENCH_OS="${OS_METADATA}" \
  ONIONPIR_BENCH_CPU="${CPU_METADATA}" \
  ONIONPIR_BENCH_COMPILER="${COMPILER_METADATA}" \
  ONIONPIR_BENCH_CMAKE="${CMAKE_METADATA}" \
  ONIONPIR_BENCH_HEXL_PATH="${HEXL_CMAKE_DIR}" \
  run_bin "merkle_${SCALE_LIST[0]}.txt" "${MERKLE_ARGS[@]}"
  command -v python3 >/dev/null && [[ -f "${OUT_DIR}/merkle.json" ]] \
    && python3 -m json.tool "${OUT_DIR}/merkle.json" >/dev/null \
    && echo "JSON validated: ${OUT_DIR}/merkle.json"
  if [[ "${WANT_4GB}" == "1" ]]; then
    if [[ ! -f "${OUT_DIR}/merkle.json" ]]; then
      record merkle_4gb fail "no merkle.json"
    elif grep -q '"skipped_resource_limit"' "${OUT_DIR}/merkle.json"; then
      echo "[skip] merkle_4gb: 套件内存门跳过了 2^26 档" >&2
      record merkle_4gb skip resource_limit
    elif grep -q '"status": "completed"' "${OUT_DIR}/merkle.json"; then
      record merkle_4gb ok
    else
      record merkle_4gb fail "optional row status missing"
    fi
  fi
fi

# 压缩门无 DB 档位, 只跑一次
if has_mode compress; then
  run_bin compress.txt --test tree_compress
fi

for SCALE in ${SCALES}; do
  LEAF_POW="$(scale_leaf_pow "${SCALE}")"
  echo "=================== 档位 ${SCALE}(L=${LEAF_POW}) ==================="
  SCALE_ARGS=(--leaf-count $((1 << LEAF_POW)) --experiments "${EXPERIMENTS}"
              --warmup "${WARMUPS}" --trial-seed "${TRIAL_SEED}")
  if has_mode tree; then
    if mem_gate "tree_g32_${SCALE}" $((1 << (LEAF_POW + 10))); then
      run_bin "tree_g32_${SCALE}.txt" --test tree_bench_g32 "${SCALE_ARGS[@]}"
    fi
  fi
  if has_mode tree-g1; then
    run_bin "tree_g1_${SCALE}.txt" --test tree_bench "${SCALE_ARGS[@]}"
  fi
  if has_mode cuckoo; then
    if mem_gate "cuckoo_${SCALE}" $((1 << (LEAF_POW + 10))); then
      run_bin "cuckoo_${SCALE}.txt" --test cuckoo_bench "${SCALE_ARGS[@]}"
    fi
  fi
  if has_mode superrecord; then
    # 同一进程含 legacy g=32 对照, 峰值与 tree_g32 同量级(顺序执行, 不叠加)。
    if mem_gate "superrecord_${SCALE}" $((1 << (LEAF_POW + 10))); then
      run_bin "superrecord_${SCALE}.txt" --test tree_superrecord_bench \
        "${SCALE_ARGS[@]}"
    fi
  fi
done

# ---------------- 完整性汇总 ----------------
echo
echo "==> 结果目录: ${OUT_DIR}"
ls -1 "${OUT_DIR}"
echo "==> 单元状态(${STATUS_FILE}):"
cat "${STATUS_FILE}"
if [[ "${FAIL_COUNT}" -gt 0 ]]; then
  echo "==> 未完成: ${FAIL_COUNT} 个单元失败, ${SKIP_COUNT} 个被跳过" >&2
  exit 1
elif [[ "${SKIP_COUNT}" -gt 0 ]]; then
  echo "==> 矩阵不完整: ${SKIP_COUNT} 个请求的单元被资源门跳过" >&2
  exit 3
fi
echo "==> 完成: 全部单元 ok"
